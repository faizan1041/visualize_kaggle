(function(){
  'use strict';

  angular
    .module('djangular.utils',[
      'djangular.utils.services'
    ]);

  angular
    .module('djangular.utils.services',[]);
})();
