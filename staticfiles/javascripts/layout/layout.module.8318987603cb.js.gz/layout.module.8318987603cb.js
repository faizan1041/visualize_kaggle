(function(){
  'use strict';

  angular
    .module('djangular.layout',[
      'djangular.layout.controllers'
    ]);

  angular.module('djangular.layout.controllers',[]);
})();
